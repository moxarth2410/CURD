const express = require ('express'); //import express npm
const app = express();  //call express
const path = require('path'); 
const userModel = require('./models/user'); //import user file from models folder
const user = require('./models/user');  

app.set("view engine" , "ejs"); //set view engine of ejs which is exactly html but with  more functionalies within
app.use(express.json()); //call json 
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname , 'public'))); // define path to public dir

app.get('/' , (req, res) => {     // create route to show/render index.ejs when "/"" is called  
    res.render("index");
})

app.get('/read', async (req,res) => {    // render "read.ejs" when /read called with async and await to complete the flow of asyncjs in sync manner 
    let users = await userModel.find(); 
    res.render("read" , {users});
})

app.get('/edit/:userid', async (req,res) => {         //render "edit.ejs" to edit created user file , find  the user with userid 
    let user = await userModel.findOne({_id: req.params.userid});
    res.render("edit" , {user});
})

app.post('/update/:userid', async (req,res) => {     // pullout the data and update with in the file and redirect the "/read" page
    let {name, image, email} = req.body;
    let user = await userModel.findOneAndUpdate({_id: req.params.userid}, {image, name, email} ,{new: true});
    res.redirect('/read');
})

app.get('/delete/:id', async (req,res) => {    // delete  the user and redirect to the "/read" page
    let users = await userModel.findOneAndDelete({_id: req.params.id}); 
    res.redirect("/read");
})

app.post('/create', async (req, res) => {  // "name: name" is also written " name, " followed by email and image
   let {name, email, image} = req.body;
    let createdUser = await userModel.create({
        name,
        email,
        image
    });
    res.redirect("/read");
})
app.listen(3000);  // port which is used as a application server "https://localhost:3000" 