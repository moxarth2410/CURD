CURD operation in Nodejs 

C-create
U-update
R-read
D-delete 

created by : Moxarth Patel
Email : moxarthpatel2410@gmail.com 
Phone: +917600607129

